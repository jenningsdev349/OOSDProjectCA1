import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
public class AddStudentGUI extends JFrame {

	JCheckBox module1;
	JCheckBox module2;
	JCheckBox module3;
	JTextArea showModules;
	ArrayList<String> studentDetails = new ArrayList<String>();

	public AddStudentGUI() {
		super("Student Information System");
		setLayout(new BorderLayout());
		JPanel panelNewStudent = new JPanel();
		panelNewStudent.setBorder(BorderFactory.createTitledBorder(BorderFactory.createRaisedBevelBorder(),
				"New Student", TitledBorder.LEFT, TitledBorder.TOP));
		panelNewStudent.setLayout(new BorderLayout());

		JPanel panelAddStudent = new JPanel();
		JPanel panelShowStudent = new JPanel();
		JPanel panelModules = new JPanel();

		// Create components of panelAddStudent
		JLabel nameLabel = new JLabel("Name: ");
		panelAddStudent.add(nameLabel);
		JTextField nameText = new JTextField("John Smith");
		nameText.setColumns(15);
		nameText.setEditable(true);
		panelAddStudent.add(nameText);
		JLabel address = new JLabel("Address :");
		panelAddStudent.add(address);
		JTextField addressText = new JTextField("35 Liffey Street, Dublin 2");
		addressText.setColumns(30);
		panelAddStudent.add(addressText);
		JButton btnSubmit = new JButton("Submit");
		JButton btnClear = new JButton("Clear");
		panelAddStudent.add(btnSubmit);
		panelAddStudent.add(btnClear);

		// Create components of panelShowStudents
		panelShowStudent.setLayout(new BorderLayout());
		JLabel studentList = new JLabel("Student List: ");
		panelShowStudent.add(studentList, BorderLayout.NORTH);
		JTextArea textAreaShowStudents = new JTextArea();
		textAreaShowStudents.setEditable(false);
		panelShowStudent.setBorder(BorderFactory.createEmptyBorder(0, 5, 5, 0));
		panelShowStudent.add(textAreaShowStudents, BorderLayout.CENTER);

		// Create components of panelModule and panelCheckBoxes
		GridLayout grid = new GridLayout(2, 1);
		panelModules.setLayout(grid);
		panelModules.setBorder(BorderFactory.createEmptyBorder(10, 5, 5, 5));
		GridLayout grid2 = new GridLayout(0, 1);
		JPanel panelCheckBoxes = new JPanel(grid2);
		module1 = new JCheckBox("Databases");
		panelCheckBoxes.add(module1);
		module2 = new JCheckBox("Java");
		panelCheckBoxes.add(module2);
		module3 = new JCheckBox("Accountancy");
		panelCheckBoxes.add(module3);
		showModules = new JTextArea();
		showModules.setEditable(false);
		showModules.setBounds(10, 10, 30, 10);
		panelModules.add(panelCheckBoxes);
		panelModules.add(showModules);

		// Create components of panelButtons
		JPanel panelButtons = new JPanel();
		add(panelButtons, BorderLayout.SOUTH);
		JButton finish = new JButton("Finish");
		JButton clearAll = new JButton("Clear All");
		panelButtons.add(finish);
		panelButtons.add(clearAll);

		// Add panels to panelNewStudent
		panelNewStudent.add(panelAddStudent, BorderLayout.NORTH);
		panelNewStudent.add(panelShowStudent, BorderLayout.CENTER);
		panelNewStudent.add(panelModules, BorderLayout.EAST);
		add(panelNewStudent);
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Submit button adds information listed in name and address fields
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = nameText.getText();
				String address = addressText.getText();
				if (!name.isEmpty() && !address.isEmpty()) {
					studentDetails.add(name + ",  " + address);
				}
				textAreaShowStudents.setText("");
				for (String student : studentDetails) {
					textAreaShowStudents.append(student + "\n");
				}
			}
		});
		
		//module checkboxes assigned to itemlisteners, when checked or unchecked updateShowModules() is called
		module1.addItemListener(new ItemListener() {
		    @Override
		    public void itemStateChanged(ItemEvent e) {
		        updateShowModules();
		    }
		});

		module2.addItemListener(new ItemListener() {
		    @Override
		    public void itemStateChanged(ItemEvent e) {
		        updateShowModules();
		    }
		});

		module3.addItemListener(new ItemListener() {
		    @Override
		    public void itemStateChanged(ItemEvent e) {
		        updateShowModules();
		    }
		});


		// Clear button clears name and address field
		btnClear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nameText.setText("");
				addressText.setText("");
			}
		});

		// Clear all button resets program to default values
		clearAll.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nameText.setText("");
				addressText.setText("");
				module1.setSelected(false);
				module2.setSelected(false);
				module3.setSelected(false);
				textAreaShowStudents.setText("");
				studentDetails.clear();
			}
		});

		// Finish button closes the program
		finish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
	}
	
	//updates text area in showModules panel to reflect user's suggestions
	public void updateShowModules() {
	    String modules = "";
	    if (module1.isSelected()) {
	        modules += "Databases\n";
	    }
	    if (module2.isSelected()) {
	        modules += "Java\n";
	    }
	    if (module3.isSelected()) {
	        modules += "Accountancy\n ";
	    }
	    showModules.setText(modules);
	}

	public static void main(String[] args) {
		AddStudentGUI gui = new AddStudentGUI();
		gui.setVisible(true);
	}

}
